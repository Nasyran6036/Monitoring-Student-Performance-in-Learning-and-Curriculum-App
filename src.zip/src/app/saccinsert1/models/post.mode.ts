export interface Post {
    studentid: string;
    BM1: number;
    BI1: number;
    MT1: number;
    SJH1: number;
    PI1: number;
    AM1: number;
    FZ1: number;
    KM1:number;
    ACC1:number;
 }
 