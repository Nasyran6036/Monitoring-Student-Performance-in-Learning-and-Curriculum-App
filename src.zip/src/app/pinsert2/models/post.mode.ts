export interface Post {
    studentid: string;
    BM2: number;
    BI2: number;
    MT2: number;
    SJH2: number;
    PI2: number;
    SENI2: number;
    PER2:number;
 }
 