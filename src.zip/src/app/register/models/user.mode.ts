export interface User {
    studentid:string;
    teacherid:string;
    teacherName:string;
    email: string;
    password: string;
    class:string;
   }