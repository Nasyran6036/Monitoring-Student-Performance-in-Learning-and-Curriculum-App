import { Component, OnInit } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { User } from '../registerstudent/models/user.mode';

@Component({
  selector: 'app-homepagestudent',
  templateUrl: './homepagestudent.page.html',
  styleUrls: ['./homepagestudent.page.scss'],
})
export class HomepagestudentPage implements OnInit {

  uid: String;
  user = {} as User;

  constructor(
    private afAuth:AngularFireAuth,
    private afStore: AngularFirestore
  ) { }

  ngOnInit() {
    this.getInfo();
  }

  async getInfo() {
    //getting current user uid
    this.uid = (await this.afAuth.currentUser).uid;
    // console.log(this.uid);

    //getting current user's basic info
    this.afStore
      .doc(( "5CEMERLANG/" + this.uid))
      .valueChanges()
      .subscribe((data) => {
        this.user.email=data['email'];
        this.user.password=data['password'];
        this.user.studentid=data['studentid'];
        this.user.studentName=data['studentName'];
        this.user.teacherName=data['teacherName'];
      });

      this.afStore
      .doc(( "5CERDIK/" + this.uid))
      .valueChanges()
      .subscribe((data) => {
        this.user.email=data['email'];
        this.user.password=data['password'];
        this.user.studentid=data['studentid'];
        this.user.studentName=data['studentName'];
        this.user.teacherName=data['teacherName'];
      });
  }
}

