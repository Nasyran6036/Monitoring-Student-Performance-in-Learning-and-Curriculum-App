export interface Post {
    studentid: string;
    BM1: number;
    BI1: number;
    MT1: number;
    SJH1: number;
    PI1: number;
    SENI1: number;
    PER1:number;
 }
 