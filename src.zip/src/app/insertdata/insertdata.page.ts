import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-insertdata',
  templateUrl: './insertdata.page.html',
  styleUrls: ['./insertdata.page.scss'],
})
export class InsertdataPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
