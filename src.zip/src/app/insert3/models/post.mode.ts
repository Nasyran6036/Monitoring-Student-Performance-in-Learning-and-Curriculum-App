export interface Post {
    studentid:string;
    teacherid:string;
    email: string;
    password: string;
    studentName:string;
    teacherName:string;
    class:string;
    BM3: number;
    BI3: number;
    MT3: number;
    SJH3: number;
    PI3: number;
    AM3: number;
    FZ3: number;
    KM3:number;
    BIO3:number;
    AC3:number;
    BS3:number;
    SV3:number;
    GEO3:number;
 }
 