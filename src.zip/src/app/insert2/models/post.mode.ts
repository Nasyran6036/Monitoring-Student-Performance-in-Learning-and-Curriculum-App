export interface Post {
    studentid:string;
    teacherid:string;
    email: string;
    password: string;
    studentName:string;
    teacherName:string;
    class:string;
    BM2: number;
    BI2: number;
    MT2: number;
    SJH2: number;
    PI2: number;
    AM2: number;
    FZ2: number;
    KM2:number;
    BIO2:number;
    AC2:number;
    BS2:number;
    SV2:number;
    GEO2:number;
 }
 