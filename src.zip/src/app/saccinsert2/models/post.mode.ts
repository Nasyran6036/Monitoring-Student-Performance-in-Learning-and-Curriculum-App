export interface Post {
    studentid: string;
    BM2: number;
    BI2: number;
    MT2: number;
    SJH2: number;
    PI2: number;
    AM2: number;
    FZ2: number;
    KM2:number;
    ACC2:number;
 }
 