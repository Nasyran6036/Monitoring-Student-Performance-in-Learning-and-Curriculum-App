export interface Post {
    studentid: string;
    BM3: number;
    BI3: number;
    MT3: number;
    SJH3: number;
    PI3: number;
    AM3: number;
    FZ3: number;
    KM3:number;
    ACC3:number;
 }
 