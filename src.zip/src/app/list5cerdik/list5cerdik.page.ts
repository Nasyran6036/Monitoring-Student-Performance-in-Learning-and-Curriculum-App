import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list5cerdik',
  templateUrl: './list5cerdik.page.html',
  styleUrls: ['./list5cerdik.page.scss'],
})
export class List5cerdikPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
