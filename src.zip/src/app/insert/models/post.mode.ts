export interface Post {
    studentid:string;
    teacherid:string;
    email: string;
    password: string;
    studentName:string;
    teacherName:string;
    class:string;
    BM1: number;
    BI1: number;
    MT1: number;
    SJH1: number;
    PI1: number;
    AM1: number;
    FZ1: number;
    KM1:number;
    BIO1:number;
    AC1:number;
    BS1:number;
    SV1:number;
    GEO1:number;
 }
 