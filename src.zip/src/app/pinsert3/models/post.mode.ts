export interface Post {
    studentid: string;
    BM3: number;
    BI3: number;
    MT3: number;
    SJH3: number;
    PI3: number;
    SENI3: number;
    PER3:number;
 }
 