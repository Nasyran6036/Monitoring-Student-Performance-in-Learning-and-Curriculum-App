import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list5bijak',
  templateUrl: './list5bijak.page.html',
  styleUrls: ['./list5bijak.page.scss'],
})
export class List5bijakPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
