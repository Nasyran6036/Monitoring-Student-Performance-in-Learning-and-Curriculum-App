export interface User {
    studentid:string;
    email: string;
    password: string;
    studentName:string;
    teacherName:string;
    class:string;

   }