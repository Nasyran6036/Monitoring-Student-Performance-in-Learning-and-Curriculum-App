import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courseseletion',
  templateUrl: './courseseletion.page.html',
  styleUrls: ['./courseseletion.page.scss'],
})
export class CourseseletionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
